# readme 

## 1. project info
```
springboot
guava 
fastjson
lombok
```

## 2. query graphql
### get continent with country code
```
query GetCountriesByCodes($code: [String]!) {
  countries(filter: { code: { in: $code } }) {
    name
    code
    continent {
      name
      code
    }
  }
}

{
  "code": ["CN"]
}
```

### get countries with continent code
```
query GetCountriesByContinents($code: [String]!) {
  countries(filter: { continent: { in: $code } }) {
    name
    code
  }
}

{
  "code": ["NA"]
}
```

## 3. rate limiter
```
Use guava limit as current limiter, demo only.
```

## 4. run with boot container
```
eg GET http://localhost:8081/country/continent?countryCodes=US,CA
```
