package com.example.takehome.entity;

import lombok.Data;

@Data
public class Query {
    private String query;
    private String variables;
    private String operationName;
}
