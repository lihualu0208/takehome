package com.example.takehome.filter;

import com.example.takehome.utils.IPUtils;
import com.google.common.util.concurrent.RateLimiter;
import io.micrometer.common.util.StringUtils;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import java.lang.reflect.Method;

import static com.example.takehome.filter.MemoryData.RATE_LIMITER_MAP;

@Slf4j
@Component
public class RequestLimiterInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (handler instanceof HandlerMethod) {
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            Method method = handlerMethod.getMethod();

            AccessLimit accessLimit = method.getAnnotation(AccessLimit.class);
            if (accessLimit == null) {
                return true;
            }
            String authParam = request.getHeader("auth");
            String key = IPUtils.getIpAddr(request) + request.getRequestURI();
            RateLimiter rateLimiter = null;

            if (!RATE_LIMITER_MAP.containsKey(key)) {
                rateLimiter = RateLimiter.create(StringUtils.isEmpty(authParam) ? accessLimit.limit() / accessLimit.sec() : accessLimit.maxlimit() / accessLimit.sec());
                RATE_LIMITER_MAP.put(key, rateLimiter);
            } else {
                rateLimiter = RATE_LIMITER_MAP.get(key);
            }

            if (!rateLimiter.tryAcquire()) {
                throw new AccessLimiterException("frequent requests");
            }
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}