package com.example.takehome.entity;

import lombok.Data;

@Data
public class Countries {
    private Country[] countries;
}
