package com.example.takehome.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "api.graphql")
@Data
public class GraphqlConfig {
    private String path;

    private final String queryCountriesByCodeName = "GetCountriesByCodes";
    private final String queryCountriesByCode = "query GetCountriesByCodes($code: [String]!) {countries(filter: {code: { in: $code }}) {name,code,continent{name,code}}}";

    private final String queryCountriesByContinetsName = "GetCountriesByContinents";
    private final String queryCountriesByContinets = "query GetCountriesByContinents($code:[String]!){countries(filter:{continent:{in:$code}}){name,code}}";
}
