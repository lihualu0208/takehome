package com.example.takehome.filter;

import com.google.common.util.concurrent.RateLimiter;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Data
public class MemoryData {
    public final static Map<String, RateLimiter> RATE_LIMITER_MAP = new ConcurrentHashMap<>();
}
