package com.example.takehome.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    public Object accessLimitExceptionHandler(Exception e) throws Exception {
        if (e instanceof AccessLimiterException) {
            return "frequent requests";
        } else {
            throw e;
        }
    }
}
