package com.example.takehome.entity;

import lombok.Data;

/**
 * 州entity
 *
 * @author AjaxD
 */
@Data
public class Continent {

    /**
     * 州编码
     */
    private String code;

    /**
     * 州名称
     */
    private String name;
}
