package com.example.takehome.entity;

import lombok.Data;

@Data
public class Country {
    private String code;
    private String name;
    private Continent continent;
}
