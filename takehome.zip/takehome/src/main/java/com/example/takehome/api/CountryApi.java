package com.example.takehome.api;

import com.alibaba.fastjson.JSONObject;
import com.example.takehome.config.GraphqlConfig;
import com.example.takehome.entity.Countries;
import com.example.takehome.entity.Country;
import com.example.takehome.entity.Query;
import com.example.takehome.filter.AccessLimit;
import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/country")
public class CountryApi {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private GraphqlConfig graphqlConfig;

    @AccessLimit
    @GetMapping("/continent")
    public Object queryContinentCountries(String[] countryCodes) {
        // 1. get continent info by the request param countryCodes
        Query query = new Query();
        query.setQuery(graphqlConfig.getQueryCountriesByCode());
        query.setOperationName(graphqlConfig.getQueryCountriesByCodeName());
        query.setVariables(JSONObject.toJSONString(new ParamData(countryCodes)));
        ResponseEntity<String> exchange = restTemplate.exchange(graphqlConfig.getPath(), HttpMethod.POST, new HttpEntity<>(query, null), String.class);
        if (exchange.getStatusCode().value() != HttpStatus.OK.value()) {
            log.error("request failed. response : {}", exchange.getBody());
            return "request failed.";
        }

        // 2. get the continent info
        String response = exchange.getBody();
        Countries countries = JSONObject.parseObject(JSONObject.parseObject(response).getString("data"), Countries.class);
        List<String> continentList = Lists.newArrayList();
        List<String> continentNameList = Lists.newArrayList();
        for (Country country : countries.getCountries()) {
            String code = country.getContinent().getCode();
            if (!continentList.contains(code)) {
                continentList.add(code);
                continentNameList.add(country.getContinent().getName());
            }
        }

        // when continent value size are more than two, throw param exception
        if (!continentList.isEmpty() && continentList.size() >= 2) {
            log.error("request country code contains multiple continent, please check param");
            return "request country code contains multiple continent, please check param";
        }

        // 3. get all country in this continent
        query = new Query();
        query.setQuery(graphqlConfig.getQueryCountriesByContinets());
        query.setOperationName(graphqlConfig.getQueryCountriesByContinetsName());
        query.setVariables(JSONObject.toJSONString(new ParamData(continentList.toArray(new String[continentList.size()]))));
        exchange = restTemplate.exchange(graphqlConfig.getPath(), HttpMethod.POST, new HttpEntity<>(query, null), String.class);
        if (exchange.getStatusCode().value() != HttpStatus.OK.value()) {
            log.error("request failed. response : {}", exchange.getBody());
            return "request failed.";
        }

        // 4. packing info. eg country continent
        response = exchange.getBody();
        countries = JSONObject.parseObject(JSONObject.parseObject(response).getString("data"), Countries.class);
        List<String> otherCountryList = Lists.newArrayList();
        List<String> countryCodeList = Arrays.stream(countryCodes).toList();
        for (Country country : countries.getCountries()) {
            if (!countryCodeList.contains(country.getCode())) {
                otherCountryList.add(country.getCode());
            }
        }

        ContinentResponse continentResponse = new ContinentResponse();
        continentResponse.setCountries(countryCodes);
        continentResponse.setName(continentNameList.get(0));
        continentResponse.setOtherCountries(otherCountryList.toArray(new String[otherCountryList.size()]));
        return new CountryApiResponse(Lists.newArrayList(continentResponse));
    }
}

/**
 * data transfer object , transfer graphql variables
 */
@Data
@AllArgsConstructor
class ParamData {
    private String[] code;
}

@Data
class ContinentResponse {
    private String[] countries;
    private String name;
    private String[] otherCountries;
}

@Data
@AllArgsConstructor
class CountryApiResponse{
    private List<ContinentResponse> continent;
}