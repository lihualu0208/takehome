package com.example.takehome.filter;

public class AccessLimiterException extends RuntimeException {

    public AccessLimiterException(String exceptionInfo) {
        super(exceptionInfo);
    }
}