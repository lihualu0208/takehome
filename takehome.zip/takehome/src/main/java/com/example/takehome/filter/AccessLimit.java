package com.example.takehome.filter;

import java.lang.annotation.*;

@Inherited
@Documented
@Target({ElementType.FIELD, ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)

public @interface AccessLimit {
    int limit() default 5;

    int maxlimit() default 20;

    //标识 时间段
    int sec() default 1;
}